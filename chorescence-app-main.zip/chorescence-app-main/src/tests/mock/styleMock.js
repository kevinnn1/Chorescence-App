module.exports = {
    process: function() {
      return "";
    }
  };